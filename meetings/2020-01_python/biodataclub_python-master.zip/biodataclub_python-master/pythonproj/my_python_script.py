def my_func(name):
    print('myname',name)